public interface Print {
    int DC_output(Adaptee adaptee);

}
