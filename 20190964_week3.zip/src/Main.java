public class Main {
    public static void main(String[] args) {
        Adaptee adaptee = new Adaptee();
        adaptee.printAC_to_DC();
    }
}